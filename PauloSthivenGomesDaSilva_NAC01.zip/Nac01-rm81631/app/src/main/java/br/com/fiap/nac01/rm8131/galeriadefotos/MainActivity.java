package br.com.fiap.nac01.rm8131.galeriadefotos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
  ImageView imgGaleria;
  //variável q  ndica a imagem no array
  int estado = 0;
//Array de imagens
  int imagens []={R.drawable.p0,
          R.drawable.p1,
          R.drawable.p2,
          R.drawable.p3,
          R.drawable.p4,
          R.drawable.p5,
          R.drawable.p6};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        imgGaleria=findViewById(R.id.imgGaleria);
        }


      //método que volta uma imagem
       public void voltarGaleria(View view) {
           if(estado==0){
               estado=imagens.length;
           }
           estado--;
           imgGaleria.setImageResource(imagens[estado]);

    }

    //método que passa uma imagem
    public void passarGaleria(View view) {
        if(estado==imagens.length-1){
            estado=-1;
        }
        estado++;
        imgGaleria.setImageResource(imagens[estado]);
    }
}
